# CRC
CRC Library to calculate 8-, 16- and 32-Bit CRC. Written in C99.

Configure needed CRC Algorithm in CRC_Cfg.h

Choose from one of the following calculation methods: Runtime calculation, pre-calculated table, hardware (not supported)
